# BinaryEditorViewer

 The BinaryEditorViewer allows the visualisation of Binary data, in binary, hexedecimal and ascii format
 It allows the editing of binary data in hex format currently and ascii and binary displays are updated 
 accordingly. Inspired by Winfred Simon's QHexEdit. 
 
![bineditorviewer](https://github.com/takavarasha-desire/BinaryEditorViewer/assets/94230493/81bea4f4-126b-4709-a0d2-1e93a5e35775)
